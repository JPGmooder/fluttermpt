class BankEntity {
  int id;
  String cardNumber;
  DateTime expDate;
  String cvc;
  BankEntity(
    this.id,
    this.cardNumber,
    this.expDate,
    this.cvc,
  );
}
