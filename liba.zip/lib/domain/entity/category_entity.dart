
class CategoryEntity {
  final String name;
  CategoryEntity({
    required this.name,
  });



}
