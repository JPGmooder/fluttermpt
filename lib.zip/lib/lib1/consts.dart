import 'package:flutter/material.dart';

const String whalePngPath = "assets/whale.png";

Color cardColor = Color.fromRGBO(65, 50, 133, 1);
Color bottomCardColor = Color.fromRGBO(25, 19, 90, 1);
